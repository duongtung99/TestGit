﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise1
{
    public class Video
    {
        public int ID { get; set; }
        public string Tittle { get; set; }
        public bool IsProcessed { get; set; }
    }
}
