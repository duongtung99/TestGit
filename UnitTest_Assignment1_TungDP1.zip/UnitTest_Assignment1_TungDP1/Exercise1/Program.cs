﻿using System;
using System.Data.Entity.Infrastructure;
using System.Linq;

namespace Exercise1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            VideoContext videoContext = new VideoContext();
            videoContext.Videos.RemoveRange(videoContext.Videos.ToList());
            videoContext.Dispose();
           // videoContext.Database.ExecuteSqlCommand("TRUNCATE Videos");
            videoContext.SaveChanges();
            //Console.WriteLine((videoContext.Videos as IObjectContextAdapter).ObjectContext.CreateObjectSet<Video>().EntitySet.Name);
        }
    }
}
