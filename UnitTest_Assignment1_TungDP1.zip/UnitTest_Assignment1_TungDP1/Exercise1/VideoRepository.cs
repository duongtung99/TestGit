﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Exercise1
{
    public class VideoRepository : IVideoRepository
    {
        public List<Video> GetUnprocessedVideoAsCsv()
        {
            using (var context = new VideoContext())
            {
                return context.Videos.Where(x => !x.IsProcessed).ToList();
            }
        }
    }
}