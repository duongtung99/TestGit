﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Exercise1
{
    public class VideoService
    {
        private IVideoRepository _videoRepository;
        public VideoService(IVideoRepository videoRepository)
        {
            _videoRepository = videoRepository;
        }
        public string GetUnprocessedVideoAsCsv()
        {
            return String.Join(",", _videoRepository.GetUnprocessedVideoAsCsv().Select(x=>x.ID).ToList());
        }
    }
}