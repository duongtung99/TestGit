﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Exercise1
{
    public interface IVideoRepository
    {
        List<Video> GetUnprocessedVideoAsCsv();
    }
}
