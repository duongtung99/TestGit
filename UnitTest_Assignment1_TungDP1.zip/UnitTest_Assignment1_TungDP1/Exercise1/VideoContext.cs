﻿using System.Data.Entity;

namespace Exercise1
{
    public class VideoContext : DbContext
    {
        public DbSet<Video> Videos { get; set; }
    }
}