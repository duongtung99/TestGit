﻿using Exercise2;
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace Exericise2
{
    public class InstallerHelper
    {
        private string _setupDestinationFile = "test.jpg";

        private IInstallerRepository installer;
        public InstallerHelper(IInstallerRepository installerRepository)
        {
            installer = installerRepository;
        }
        public bool DownloadInstaller(string customerName,string installerName)
        {
            try
            {
                return installer.DownloadInstaller(customerName,installerName,_setupDestinationFile);
            }
            catch (WebException)
            {
                return false;
            }
        }
    }
}
