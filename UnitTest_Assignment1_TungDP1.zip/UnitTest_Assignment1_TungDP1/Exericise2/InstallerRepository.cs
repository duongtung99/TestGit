﻿using System.Net;

namespace Exercise2
{
    public class InstallerRepository : IInstallerRepository
    {
        public bool DownloadInstaller(string customerName, string installerName, string setupName)
        {
            new WebClient().DownloadFile(
            string.Format(@"https://images.wallpaperscraft.com/image/{0}/{1}",
            customerName,
            installerName),
            setupName);
            return true;
        }
    }
}