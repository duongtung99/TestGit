﻿namespace Exercise2
{
    public interface IInstallerRepository
    {
        bool DownloadInstaller(string customerName, string installerName, string setupName);
    }
}