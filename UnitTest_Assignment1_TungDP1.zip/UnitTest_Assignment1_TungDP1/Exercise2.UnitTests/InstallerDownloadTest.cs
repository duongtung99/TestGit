﻿using Exericise2;
using Moq;
using NUnit.Framework;
using System.Net;

namespace Exercise2.UnitTests
{
    public class InstallerDownloadTest
    {
        private Mock<IInstallerRepository> _mockReposity;
        private InstallerHelper _installerHelper;
        [SetUp]
        public void Setup()
        {
            _mockReposity = new Mock<IInstallerRepository>();
            _installerHelper = new InstallerHelper(_mockReposity.Object);
        }
        [Test]
        public void DownloadInstaller_DownloadFails_ReturnFalse()
        {
            _mockReposity.Setup(x=> x.DownloadInstaller(@"single.com.vn", @"lmao/dsffff.jpg","test.jpg")).Throws(new WebException());

            var result = _installerHelper.DownloadInstaller(@"single.com.vn", @"lmao/dsffff.jpg");

            Assert.That(result, Is.False);
        }

        [Test]
        public void DownloadInstaller_DownloadCompletes_ReturnTrue()
        {
            _mockReposity.Setup(x => x.DownloadInstaller(@"single", @"girl_glance_wind_220849_1280x720.jpg", "test.jpg")).Returns( true);

            var result = _installerHelper.DownloadInstaller(@"single", @"girl_glance_wind_220849_1280x720.jpg");

            Assert.That(result, Is.True);
        }
    }
}