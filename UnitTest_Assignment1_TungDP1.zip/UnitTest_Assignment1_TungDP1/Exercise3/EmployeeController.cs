﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise3
{
    public class EmployeeController
    {
        private IEmployeeReposity reposity;
        public EmployeeController(IEmployeeReposity employeeReposity)
        {
            reposity = employeeReposity;
        }
        public ActionResult DeleteEmployee(int id)
        {
            if (reposity.DeleteEmployee(id))
            {
                return RedirectToAction("Employee");
            }
            return new NotFoundResult();
        }
        public ActionResult RedirectToAction(string employee)
        {
            return new RedirectResult();
        }
    }
}
