﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise3
{
    public class EmployeeReposity : IEmployeeReposity
    {
        private EmployeeContext _db;
        public EmployeeReposity(EmployeeContext employeeContext )
        {
            _db = employeeContext;
        }
        public bool DeleteEmployee(int id)
        {
            var employee = _db.Employees.Find(id);
            if (employee != null)
            {
                _db.Employees.Remove(employee);
                _db.SaveChanges();
                return true;
            }
            return false;
        }
    }
}
