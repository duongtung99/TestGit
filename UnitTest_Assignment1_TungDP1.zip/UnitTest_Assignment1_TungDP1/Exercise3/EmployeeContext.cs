﻿using System.Data.Entity;

namespace Exercise3
{
    public class EmployeeContext : DbContext
    {
        public DbSet<Employee> Employees { get; set; }
        //public void SaveChanges()
        //{
        //}
    }
}