﻿using Microsoft.AspNetCore.Mvc;

namespace Exercise3
{
    public interface IEmployeeReposity
    {
        bool DeleteEmployee(int id);
    }
}