using Microsoft.AspNetCore.Mvc;
using Moq;
using NUnit.Framework;

namespace Exercise3.EmployeeControllerTest
{
    [TestFixture]
    public class EmployeeControllerTest
    {
        private Mock<IEmployeeReposity> _mockReposity;
        private EmployeeController _employeeController;
        [SetUp]
        public void Setup()
        {
            _mockReposity = new Mock<IEmployeeReposity>();
            _employeeController = new EmployeeController(_mockReposity.Object);
        }
        [Test]
        public void DeleteEmployee_WhenCalled_DeleteTheEmployeeFromDb()
        {
            _mockReposity.Setup(x=>x.DeleteEmployee(1)).Returns(true);
            var result = _employeeController.DeleteEmployee(1);
            Assert.That(result,Is.TypeOf<RedirectResult>());
        }
    }
}