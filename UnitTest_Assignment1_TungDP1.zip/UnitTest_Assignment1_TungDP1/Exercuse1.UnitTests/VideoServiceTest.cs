﻿using Exercise1;
using Moq;
using NUnit.Framework;
using System.Collections.Generic;
using System.Linq;

namespace Exercuse1.UnitTests
{
    [TestFixture]
    public class VideoServiceTest
    {
        private Mock<IVideoRepository> _mockReposity;
        private VideoService _videoService;
        [SetUp]
        public void Setup()
        {
            _mockReposity = new Mock<IVideoRepository>();
            _videoService = new VideoService(_mockReposity.Object);
        }
        [Test]
        public void GetUnprocessedVideoCsv_AllVideosAreProcessed_ReturnAnEmpytyString()
        {
            //
            _mockReposity.Setup(x => x.GetUnprocessedVideoAsCsv()).Returns(new List<Video>()); // Return empty list video

            //2. Action: Excute method setup
            var result = _videoService.GetUnprocessedVideoAsCsv();

            //3. Compare
            Assert.That(result, Is.Empty);

        }

        [Test]
        public void GetUnprocessedVideoCsv_AFewAreProcessed_ReturnAStringWithIdOfUnprocessedVideos()
        {
            //
            _mockReposity.Setup(x => x.GetUnprocessedVideoAsCsv()).
                Returns(new List<Video>()
                { new Video() {ID = 1,IsProcessed = true, Tittle ="Video 1" },
                new Video() {ID = 2,IsProcessed = false, Tittle ="Video 2" },
                new Video() {ID = 3,IsProcessed = false, Tittle ="Video 3" },
                }.Where(x=>!x.IsProcessed).ToList()); // Return empty list video

            //2. Action: Excute method setup
            var result = _videoService.GetUnprocessedVideoAsCsv();

            //3. Compare
            Assert.That(result, Is.EqualTo("2,3"));

        }
    }
}